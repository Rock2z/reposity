package com.example.nginxtest2.nginxtest2;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpSession;

@Controller
public class TestController {
    @RequestMapping("/hello")
    public String hello(HttpSession session){
        session.setAttribute("user", "li_yi_meng");
        return "hello";
    }

    @ResponseBody
    @RequestMapping("who")
    public String who(HttpSession session){
        Object s = session.getAttribute("user");
        if(s==null) return "Nothing";
        else {
            session.removeAttribute("user");
            return s.toString();
        }
    }

}
