package com.example.nginxtest2.nginxtest2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Nginxtest2Application {

    public static void main(String[] args) {
        SpringApplication.run(Nginxtest2Application.class, args);
    }

}
