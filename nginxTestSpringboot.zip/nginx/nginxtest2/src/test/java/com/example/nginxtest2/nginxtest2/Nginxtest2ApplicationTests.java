package com.example.nginxtest2.nginxtest2;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@SpringBootTest
public class Nginxtest2ApplicationTests {

    @Test
    public void contextLoads() {
    }

}
